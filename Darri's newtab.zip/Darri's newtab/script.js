console.log("Script ran");
let darri = document.getElementById("darri");
let subtitles = document.getElementById("subtitles");

let shortcuts = document.getElementById("shortcuts");
let apps = document.getElementById("apps");//div elements of all shortcuts
let submit = document.getElementById("ask");
let question = document.getElementById("question");
//yt search
let searchVideo = document.getElementById("youtubeSearch");
let findVideo = document.getElementById("submitSearch");

subtitles.style.display = "block";
setTimeout(() => {
    subtitles.style.display = "none";
}, 2000);
darri.addEventListener("click", () => {
    let subtitles = document.getElementById("subtitles");
    subtitles.textContent = "Hi! ... you should get my dialouge working, Darrick.";//[Darri] Hello! 
    subtitles.style.display = "block";
    setTimeout(() => {
        subtitles.style.display = "none";
    }, 3000);
});
shortcuts.addEventListener("click", () => {
    apps.style.display = "flex";
});
function googleSearch() {
        window.location.href = "https://www.google.com/search?q=" + question.value;
        //console.log(question.textContent);
}
submit.addEventListener("click", () => {
    googleSearch();
});
findVideo.addEventListener("click", () => {
    window.location.href = "https://www.youtube.com/results?search_query=" + searchVideo.value;
});
document.addEventListener("keydown", (event) => {
	if(event.key === "Enter") {
	//when enter key is pressed
	if(question.value) {
		googleSearch();
	} else {
		window.location.href = "https://www.youtube.com/results?search_query=" + searchVideo.value;
	}
	//==========================
	}
});